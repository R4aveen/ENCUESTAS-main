
from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [
        ('core', '0001_initial'),
    ]

    operations = [
        # No-op: maneja la migración anterior que fue revertida manualmente en el código.
    ]
