from django.apps import AppConfig


class TerritorialAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'territorial_app'
