# 🗳️ Proyecto Encuestas

Sistema de **encuestas e incidencias** desarrollado con **Django + PostgreSQL**, con vistas web por rol y API REST para consumir desde otras apps (React/TypeScript).

## 🚀 Funcionalidades principales
- **Autenticación y Roles**: Administrador, Dirección, Departamento, Jefe de Cuadrilla, Territorial.
- **Gestión de Usuarios (core/personas)**: listar (buscador), crear, editar, ver detalle, activar/bloquear y eliminar suave; roles aplicados con decoradores.
- **Incidencias (incidencias/organizacion)**: registrar incidencias, asignar cuadrillas, subir evidencias, transicionar estados y filtrar por rol/estado.
- **Encuestas (territorial_app/encuestas_app)**: CRUD con bloqueo de edición si están activas, multimedia y datos de vecino, asociación a tipo de incidencia.
- **Organización (organizacion/)**: Dirección y Departamento con activación/bloqueo y asignación de encargados.
- **Territorial**: validación/rechazo/reasignación de incidencias y dashboard de estado.
- **Templates unificados**: navbar dinámico, botón volver, visor modal de imágenes, diseño responsivo.

## 📂 Estructura del Proyecto
- `encuestas/` → Configuración principal (settings, urls, wsgi/asgi).
- `core/` → Modelos clave (Dirección, Departamento, Encuesta, Incidencia, JefeCuadrilla, TipoIncidencia, Multimedia), formularios y utilidades de rol.
- `personas/` → Dashboards por rol y CRUD de usuarios.
- `organizacion/` → CRUD de Direcciones/Departamentos y asignación de cuadrillas.
- `incidencias/` → CRUD incidencias, evidencias, flujos de estado y API de cuadrilla.
- `territorial_app/` → CRUD encuestas y acciones territorial (validar/rechazar/reasignar).
- `registration/` → Autenticación extendida y perfiles.
- `templates/` → Plantillas globales (`base.html`, `registration/`, `core/`, etc.).

## 🔒 Seguridad / Accesos
- Autenticación: login web con sesión Django; API protegida con TokenAuth (`/api/auth/token/`).
- Autorización: control por grupos (roles) y decoradores (`@solo_admin`, etc.); filtros por rol en incidencias (_filtrar_por_rol).
- CSRF: habilitado en vistas web; para API usar el header `Authorization: Token <token>`.
- Passwords: gestionados por Django auth; recuperación de contraseña vía vistas estándar de Django.

## ⚙️ Instalación rápida

```bash
# Crear entorno virtual (ej. con venv)
python -m venv venv
./venv/Scripts/activate  # Windows

# Instalar dependencias
pip install -r requirements.txt

# Migrar la base de datos
python manage.py migrate

# Crear superusuario (si aún no existe)
python manage.py createsuperuser

# Ejecutar servidor de desarrollo
python manage.py runserver
```

## 📦 Dependencias principales (requirements.txt)
- asgiref==3.10.0
- Django==5.2.4
- djangorestframework==3.15.2
- djangorestframework-simplejwt==5.3.1
- pip==25.2
- psycopg==3.2.12 / psycopg-binary==3.2.12
- PyJWT==2.10.1
- sqlparse==0.5.3
- tzdata==2025.2

## 🔐 Roles disponibles
- Administrador
- Dirección
- Departamento
- Jefe de Cuadrilla
- Territorial

## 🌐 Endpoints API (DRF)
- `POST /api/auth/token/`  
  Body: `{"username": "...", "password": "..."}` → `{"token": "abc123"}`  
  Header: `Authorization: Token abc123`
- `GET /incidencias/api/cuadrilla/incidencias/?estado=en_proceso`  
  Lista incidencias asignadas a la cuadrilla del usuario autenticado. `estado` opcional: `pendiente|en_proceso|finalizada|validada|rechazada`.
- `POST|PATCH /incidencias/api/cuadrilla/incidencias/<id>/resolver/`  
  Body opcional: `{"evidencia_urls": ["https://..."], "comentario": "texto"}`. Cambia a `finalizada` si está en `en_proceso` y asignada a su cuadrilla.

## 📊 Flujo resumido por rol
- **Admin**: crea usuarios, direcciones, departamentos, incidencias, encuestas, tipos; asigna cuadrillas.
- **Territorial**: crea incidencias, valida/rechaza finalizadas, reasigna; CRUD encuestas (edición bloqueada si está activa).
- **Dirección/Departamento**: dashboards filtrados; Departamento asigna cuadrilla a pendientes (pasa a “en_proceso”).
- **Jefe de Cuadrilla**: ve incidencias de sus cuadrillas, sube evidencias y finaliza en_proceso; en la API solo recibe las suyas.

## 🧪 Checklist rápido
- Crear usuario jefe de cuadrilla y cuadrilla asociada; asignar incidencia en `en_proceso`; validar que aparece en API `.../cuadrilla/incidencias/`.
- Crear/editar encuestas y probar bloqueo de edición si están activas.
- Asignar cuadrilla a incidencia pendiente (Depto/Admin) y finalizar con evidencias (Jefe de Cuadrilla); validar/rehusar desde Territorial.

## 🧰 Librerías clave (versiones usadas)
- Django 5.2.4  
- Django REST Framework 3.15.2  
- djangorestframework-simplejwt 5.3.1 (instalada; login actual usa TokenAuth)  
- PostgreSQL (configurable en `encuestas/settings.py`)
